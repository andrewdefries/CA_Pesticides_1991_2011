
for i in *.sdf

do

mkdir $i.temp
cp $i $i.temp
cd $i.temp 
babel $i $i.frag.sdf -m 
rm $i

find . -exec grep -q '\*' '{}' \; -delete
find . -exec grep -q 'R#' '{}' \; -delete
find . -exec grep -q 'A   0  0' '{}' \; -delete
find . -exec grep -q 'R' '{}' \; -delete
find . -exec grep -q 'n0 1' '{}' \; -delete

mkdir Good
mv *.sdf Good
cd Good
babel *.sdf $i.good.sdf
mv $i.good.sdf Clean.$i

#sed -i '/OpenBabel/d' Use.sdf 



rm $i.frag*

cd ~/Desktop/fmcsRthat

done

